#include "../../tools/assistant/compat/lib/qassistantclient.h"
