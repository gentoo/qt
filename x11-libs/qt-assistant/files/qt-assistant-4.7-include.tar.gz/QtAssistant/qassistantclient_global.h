#include "../../tools/assistant/compat/lib/qassistantclient_global.h"
